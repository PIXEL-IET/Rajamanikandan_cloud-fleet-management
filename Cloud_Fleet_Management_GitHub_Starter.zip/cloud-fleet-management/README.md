# Cloud Fleet & Infrastructure Management Dashboard

A portfolio project built with **Django REST Framework + React** to demonstrate fleet/infrastructure inventory, health monitoring, filtering, and basic operational actions.

> Portfolio/demo application only. It does not connect to a real cloud provider or execute infrastructure changes.

## Features
- Fleet overview with device/server counts and health status
- Inventory table with search and status filtering
- REST API for listing and creating assets, viewing a single asset, and changing status
- Seed command to load realistic demo data
- React dashboard UI with summary cards and responsive layout
- SQLite for local development

## Tech stack
- Python 3.11+, Django, Django REST Framework
- React, Vite, JavaScript
- SQLite

## Quick start

### 1. Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_assets
python manage.py runserver
```
API runs at `http://127.0.0.1:8000/api/assets/`.

### 2. Frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL printed in the terminal. The UI expects the API at `http://127.0.0.1:8000`.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/assets/` | List assets; supports `?search=` and `?status=` |
| POST | `/api/assets/` | Create an asset |
| GET | `/api/assets/<id>/` | Retrieve one asset |
| PATCH | `/api/assets/<id>/status/` | Update asset status |
| GET | `/api/summary/` | Dashboard counts |

Example:
```bash
curl http://127.0.0.1:8000/api/assets/
```

## Suggested next improvements
- Add authentication and role-based permissions
- Add automated tests with pytest or Django TestCase
- Add pagination and audit logs
- Integrate a real cloud API in a sandbox with read-only permissions
- Add CI with GitHub Actions and container deployment

## Resume-ready project description
**Cloud Fleet & Infrastructure Management Dashboard | Django REST Framework, React, SQLite**
- Built a full-stack dashboard concept to track infrastructure assets, health states, locations, and last-seen timestamps.
- Implemented REST endpoints for inventory search, status filtering, asset creation, and summary metrics.
- Developed a React interface with responsive KPI cards and a searchable asset table.

Only include the project on a resume after you have run it, reviewed the code, and can explain the implementation in an interview.
