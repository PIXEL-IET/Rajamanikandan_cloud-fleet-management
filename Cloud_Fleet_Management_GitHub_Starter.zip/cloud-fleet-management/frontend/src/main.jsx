import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API = 'http://127.0.0.1:8000/api';
const demoAssets = [
  {id:1,name:'api-prod-01',asset_type:'Application Server',environment:'Production',region:'ap-south-1',status:'healthy',ip_address:'10.0.1.10'},
  {id:2,name:'worker-prod-02',asset_type:'Worker Node',environment:'Production',region:'ap-south-1',status:'warning',ip_address:'10.0.1.21'},
  {id:3,name:'db-stage-01',asset_type:'Database',environment:'Staging',region:'ap-south-1',status:'healthy',ip_address:'10.0.2.15'},
  {id:4,name:'edge-node-07',asset_type:'Edge Device',environment:'Production',region:'eu-west-1',status:'offline',ip_address:'10.2.0.7'},
  {id:5,name:'monitor-dev-01',asset_type:'Monitoring Server',environment:'Development',region:'ap-south-1',status:'maintenance',ip_address:'10.0.3.9'}
];
function App() {
  const [assets, setAssets] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [apiState, setApiState] = useState('connecting');
  useEffect(() => {
    fetch(`${API}/assets/`).then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(data => { setAssets(data); setApiState('connected'); })
      .catch(() => { setAssets(demoAssets); setApiState('demo'); });
  }, []);
  const shown = useMemo(() => assets.filter(a =>
    `${a.name} ${a.asset_type} ${a.environment} ${a.region}`.toLowerCase().includes(search.toLowerCase()) &&
    (filter === 'all' || a.status === filter)), [assets, search, filter]);
  const counts = useMemo(() => ({
    total: assets.length,
    healthy: assets.filter(a => a.status === 'healthy').length,
    warning: assets.filter(a => a.status === 'warning').length,
    offline: assets.filter(a => a.status === 'offline').length
  }), [assets]);
  return <main className="shell">
    <aside className="sidebar"><div className="brand"><span className="brand-mark">CF</span><div><b>CloudFleet</b><small>INFRA CONSOLE</small></div></div>
      <div className="nav-label">WORKSPACE</div><div className="nav active">▦　Overview</div><div className="nav">▤　Asset inventory</div><div className="nav">◷　Activity logs</div>
      <div className="sidebar-bottom"><div className="avatar">RM</div><div><b>Portfolio Demo</b><small>Local environment</small></div></div>
    </aside>
    <section className="content"><header><div><p className="eyebrow">INFRASTRUCTURE / OVERVIEW</p><h1>Fleet overview</h1><p className="subtitle">A single view of your infrastructure health and inventory.</p></div>
      <span className={`connection ${apiState}`}>● {apiState === 'connected' ? 'API connected' : apiState === 'demo' ? 'Demo data · API offline' : 'Connecting'}</span></header>
      <div className="notice">Demo environment <span>Sample inventory only — no real infrastructure is connected.</span></div>
      <div className="metrics">
        <Metric label="Total assets" value={counts.total} detail="Across all environments" icon="▦"/>
        <Metric label="Healthy" value={counts.healthy} detail="Operating normally" icon="✓" status="green"/>
        <Metric label="Needs attention" value={counts.warning} detail="Warnings detected" icon="!" status="amber"/>
        <Metric label="Offline" value={counts.offline} detail="Not reporting" icon="↯" status="red"/>
      </div>
      <section className="panel"><div className="panel-head"><div><h2>Asset inventory</h2><p>Monitor servers, worker nodes, databases and edge devices.</p></div><span className="count">{shown.length} assets</span></div>
        <div className="toolbar"><input aria-label="Search assets" placeholder="⌕  Search by name, type, region..." value={search} onChange={e=>setSearch(e.target.value)}/>
          <select aria-label="Filter status" value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All statuses</option><option value="healthy">Healthy</option><option value="warning">Warning</option><option value="offline">Offline</option><option value="maintenance">Maintenance</option></select></div>
        <div className="table-wrap"><table><thead><tr><th>ASSET</th><th>TYPE</th><th>ENVIRONMENT</th><th>REGION</th><th>STATUS</th><th>IP ADDRESS</th></tr></thead>
          <tbody>{shown.map(a=><tr key={a.id}><td><b className="asset-name">{a.name}</b><small>ID · {String(a.id).padStart(4,'0')}</small></td><td>{a.asset_type}</td><td><span className="environment">{a.environment}</span></td><td>{a.region}</td><td><span className={`status ${a.status}`}><i/> {a.status}</span></td><td className="ip">{a.ip_address || '—'}</td></tr>)}
          {shown.length===0 && <tr><td colSpan="6" className="empty">No assets match your search.</td></tr>}</tbody></table></div>
        <footer><span>Showing {shown.length} of {assets.length} assets</span><span>Last refreshed on page load</span></footer>
      </section>
      <p className="footnote">CloudFleet Portfolio Project · React + Django REST Framework</p>
    </section>
  </main>;
}
function Metric({label,value,detail,icon,status=''}) { return <article className="metric"><div className={`metric-icon ${status}`}>{icon}</div><p>{label}</p><strong>{value}</strong><small>{detail}</small></article>; }
createRoot(document.getElementById('root')).render(<App />);
