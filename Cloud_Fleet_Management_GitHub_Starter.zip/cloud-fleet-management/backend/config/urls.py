from django.contrib import admin
from django.urls import path, include
from fleet.views import summary

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("fleet.urls")),
    path("api/summary/", summary, name="summary"),
]
