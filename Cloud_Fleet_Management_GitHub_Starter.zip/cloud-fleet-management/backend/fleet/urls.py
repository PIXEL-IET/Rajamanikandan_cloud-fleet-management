from django.urls import path
from .views import AssetListCreateView, AssetDetailView, update_status

urlpatterns = [
    path("assets/", AssetListCreateView.as_view(), name="asset-list"),
    path("assets/<int:pk>/", AssetDetailView.as_view(), name="asset-detail"),
    path("assets/<int:pk>/status/", update_status, name="asset-status"),
]
