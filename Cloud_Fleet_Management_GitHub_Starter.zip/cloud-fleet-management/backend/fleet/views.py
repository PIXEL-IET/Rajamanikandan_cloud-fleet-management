from django.db.models import Q
from rest_framework import generics, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Asset
from .serializers import AssetSerializer

class AssetListCreateView(generics.ListCreateAPIView):
    serializer_class = AssetSerializer

    def get_queryset(self):
        queryset = Asset.objects.all()
        search = self.request.query_params.get("search", "").strip()
        asset_status = self.request.query_params.get("status", "").strip().lower()
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) | Q(asset_type__icontains=search) |
                Q(environment__icontains=search) | Q(region__icontains=search)
            )
        if asset_status and asset_status != "all":
            queryset = queryset.filter(status=asset_status)
        return queryset

class AssetDetailView(generics.RetrieveAPIView):
    queryset = Asset.objects.all()
    serializer_class = AssetSerializer

@api_view(["PATCH"])
def update_status(request, pk):
    try:
        asset = Asset.objects.get(pk=pk)
    except Asset.DoesNotExist:
        return Response({"detail": "Asset not found."}, status=status.HTTP_404_NOT_FOUND)
    new_status = request.data.get("status")
    valid = {choice[0] for choice in Asset.STATUS_CHOICES}
    if new_status not in valid:
        return Response({"status": ["Choose a valid status."]}, status=status.HTTP_400_BAD_REQUEST)
    asset.status = new_status
    asset.save(update_fields=["status", "last_seen"])
    return Response(AssetSerializer(asset).data)

@api_view(["GET"])
def summary(request):
    assets = Asset.objects.all()
    counts = {key: assets.filter(status=key).count()
              for key in ["healthy", "warning", "offline", "maintenance"]}
    return Response({"total": assets.count(), **counts})
