from django.db import models

class Asset(models.Model):
    STATUS_CHOICES = [
        ("healthy", "Healthy"),
        ("warning", "Warning"),
        ("offline", "Offline"),
        ("maintenance", "Maintenance"),
    ]
    name = models.CharField(max_length=120)
    asset_type = models.CharField(max_length=60, default="Server")
    environment = models.CharField(max_length=40, default="Development")
    region = models.CharField(max_length=80, default="ap-south-1")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="healthy")
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    last_seen = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.status})"
