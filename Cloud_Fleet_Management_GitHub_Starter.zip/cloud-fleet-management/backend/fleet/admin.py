from django.contrib import admin
from .models import Asset
@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ("name", "asset_type", "environment", "region", "status", "last_seen")
    list_filter = ("status", "environment", "region")
    search_fields = ("name", "asset_type", "region")
