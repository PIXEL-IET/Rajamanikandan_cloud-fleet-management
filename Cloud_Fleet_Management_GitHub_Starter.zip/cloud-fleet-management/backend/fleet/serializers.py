from rest_framework import serializers
from .models import Asset

class AssetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Asset
        fields = ["id", "name", "asset_type", "environment", "region", "status",
                  "ip_address", "last_seen", "created_at"]
        read_only_fields = ["id", "last_seen", "created_at"]
