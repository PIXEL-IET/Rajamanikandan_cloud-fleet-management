from django.core.management.base import BaseCommand
from fleet.models import Asset

class Command(BaseCommand):
    help = "Create demo fleet assets"

    def handle(self, *args, **options):
        samples = [
            ("api-prod-01", "Application Server", "Production", "ap-south-1", "healthy", "10.0.1.10"),
            ("worker-prod-02", "Worker Node", "Production", "ap-south-1", "warning", "10.0.1.21"),
            ("db-stage-01", "Database", "Staging", "ap-south-1", "healthy", "10.0.2.15"),
            ("edge-node-07", "Edge Device", "Production", "eu-west-1", "offline", "10.2.0.7"),
            ("monitor-dev-01", "Monitoring Server", "Development", "ap-south-1", "maintenance", "10.0.3.9"),
        ]
        created = 0
        for name, kind, env, region, state, ip in samples:
            _, was_created = Asset.objects.get_or_create(
                name=name, defaults={"asset_type": kind, "environment": env,
                "region": region, "status": state, "ip_address": ip})
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Seed complete: {created} assets added."))
